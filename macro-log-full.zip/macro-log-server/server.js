'use strict';
/*
 * Macro Log backend. No npm dependencies. Needs Node 22.5 or newer (uses the built-in node:sqlite).
 *  - Serves the web app from ./public
 *  - Passcode login with a signed, httpOnly session cookie
 *  - Stores your whole log as one JSON document in SQLite, with a revision counter for safe multi-device sync
 *  - Proxies photo and text analysis to Gemini or OpenAI so the API keys never reach the browser
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');

/* ---------- config ---------- */
const env = process.env;
const PORT = Number(env.PORT) || 3000;
const HOST = env.HOST || '0.0.0.0';
const DATA_DIR = env.DATA_DIR || path.join(__dirname, 'data');
const PASSCODE = env.APP_PASSCODE || '';
const ALLOW_NO_AUTH = env.ALLOW_NO_AUTH === '1';
const TRUST_PROXY = env.TRUST_PROXY === '1';
const MOCK_AI = env.MOCK_AI === '1';
const GEMINI_KEY = (env.GEMINI_API_KEY || '').trim();
const OPENAI_KEY = (env.OPENAI_API_KEY || '').trim();
const GEMINI_MODEL = env.GEMINI_MODEL || 'gemini-2.5-flash';
const OPENAI_MODEL = env.OPENAI_MODEL || 'gpt-4.1-mini';
const GROUNDING = env.GEMINI_GROUNDING === '1';
const DEFAULT_PROVIDER = env.AI_PROVIDER || (GEMINI_KEY ? 'gemini' : 'openai');
const SESSION_DAYS = 30;

if (!PASSCODE && !ALLOW_NO_AUTH) {
  console.error('Set APP_PASSCODE to a long passphrase (or ALLOW_NO_AUTH=1 for local testing only).');
  process.exit(1);
}
if (PASSCODE && PASSCODE.length < 8) {
  console.error('APP_PASSCODE must be at least 8 characters.');
  process.exit(1);
}
fs.mkdirSync(DATA_DIR, { recursive: true });

/* ---------- storage ---------- */
const db = new DatabaseSync(path.join(DATA_DIR, 'macrolog.db'));
db.exec(`
  PRAGMA journal_mode = WAL;
  CREATE TABLE IF NOT EXISTS doc (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    rev INTEGER NOT NULL,
    json TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS snapshots (
    day TEXT PRIMARY KEY,
    json TEXT NOT NULL
  );
`);
const qGet = db.prepare('SELECT rev, json FROM doc WHERE id = 1');
const qIns = db.prepare('INSERT INTO doc (id, rev, json, updated_at) VALUES (1, ?, ?, ?)');
const qUpd = db.prepare('UPDATE doc SET rev = ?, json = ?, updated_at = ? WHERE id = 1');
const qSnap = db.prepare('INSERT OR REPLACE INTO snapshots (day, json) VALUES (?, ?)');
const qSnapOld = db.prepare('DELETE FROM snapshots WHERE day < ?');

function getDoc() {
  const row = qGet.get();
  return row ? { rev: row.rev, state: JSON.parse(row.json) } : { rev: 0, state: null };
}
function putDoc(rev, jsonText) {
  const now = new Date().toISOString();
  if (rev === 1) qIns.run(rev, jsonText, now); else qUpd.run(rev, jsonText, now);
  // one rolling snapshot per day, kept for 30 days, so a bad sync can be undone
  const day = now.slice(0, 10);
  qSnap.run(day, jsonText);
  qSnapOld.run(new Date(Date.now() - 30 * 864e5).toISOString().slice(0, 10));
}

/* ---------- sessions ---------- */
function loadSecret() {
  if (env.SESSION_SECRET) return env.SESSION_SECRET;
  const f = path.join(DATA_DIR, 'session.key');
  try { return fs.readFileSync(f, 'utf8'); } catch (e) {}
  const s = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(f, s, { mode: 0o600 });
  return s;
}
const SECRET = loadSecret();
const sign = v => crypto.createHmac('sha256', SECRET).update(v).digest('base64url');
function makeToken() { const exp = Date.now() + SESSION_DAYS * 864e5; const v = String(exp); return v + '.' + sign(v); }
function validToken(t) {
  if (!t) return false;
  const [v, sig] = String(t).split('.');
  if (!v || !sig) return false;
  const good = sign(v);
  const a = Buffer.from(sig), b = Buffer.from(good);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return false;
  return Number(v) > Date.now();
}
function cookies(req) {
  const out = {};
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
const isAuthed = req => ALLOW_NO_AUTH && !PASSCODE ? true : validToken(cookies(req).ml_session);
function safeEqual(a, b) {
  const x = crypto.createHash('sha256').update(String(a)).digest();
  const y = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(x, y);
}

/* ---------- tiny rate limiter ---------- */
const buckets = new Map();
function limited(key, max, windowMs) {
  const now = Date.now();
  const b = (buckets.get(key) || []).filter(t => now - t < windowMs);
  if (b.length >= max) { buckets.set(key, b); return true; }
  b.push(now); buckets.set(key, b); return false;
}
function failedLoginCount(key, windowMs) {
  const now = Date.now();
  return (buckets.get(key) || []).filter(t => now - t < windowMs).length;
}
function clientIp(req) {
  if (TRUST_PROXY) {
    const x = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (x) return x;
  }
  return req.socket.remoteAddress || 'unknown';
}

/* ---------- AI ---------- */
function buildPrompt(note, rest, city, savedFoods) {
  const r1 = v => Math.round((Number(v) || 0) * 10) / 10;
  const saved = (Array.isArray(savedFoods) ? savedFoods : []).slice(0, 40)
    .map(f => `${String(f.name).slice(0, 80)} | ${r1(f.kcal)} cal | P ${r1(f.p)} | C ${r1(f.c)} | F ${r1(f.f)} | fiber ${r1(f.fiber)}`).join('\n');
  return `You are a careful nutrition logging assistant. Work out what the person ate from the photo and/or notes and estimate nutrition for what they actually consumed.

Notes from the person: ${note ? '"' + note + '"' : '(none)'}
Restaurant: ${rest || '(none given)'}
City: ${city || '(none given)'}

Rules:
- List each distinct food or drink as its own item, with the portion you assumed (for example "1 cup", "2 sticks", "about 6 oz").
- When the notes name a store brand or product (for example Trader Joe's or Publix items), use that product's real label values per serving as best you know them, scaled by the quantity in the notes.
- When a restaurant or city is given, prefer that restaurant's published menu nutrition if it is a known chain. For a local place, estimate from typical dishes of that kind and size. Mention the assumption in notes.
- If an item matches one of the person's saved foods below, reuse that exact name and those exact numbers (scale only if the portion clearly differs).
- Use the photo to judge portion sizes. If something is hidden or unclear, state your assumption in notes and set confidence to "low".
- Numbers must be plain numbers, no ranges.

Saved foods (name | calories | protein g | carbs g | fat g | fiber g):
${saved || '(none yet)'}

Reply with ONLY a JSON object in this exact shape:
{"items":[{"name":"string","portion":"string","calories":0,"protein_g":0,"carbs_g":0,"fat_g":0,"fiber_g":0,"confidence":"high|medium|low"}],"notes":"string"}`;
}

async function httpJson(url, opts) {
  let r;
  try { r = await fetch(url, Object.assign({ signal: AbortSignal.timeout(60000) }, opts)); }
  catch (e) { throw httpError(502, 'Could not reach the AI service.'); }
  const txt = await r.text();
  let j = null; try { j = JSON.parse(txt); } catch (e) {}
  if (!r.ok) {
    const msg = (j && j.error && j.error.message) || txt.slice(0, 200) || r.statusText;
    console.error('AI error', r.status, msg);
    throw httpError(502, `AI service error ${r.status}: ${msg}`);
  }
  return j;
}
async function askGemini(prompt, image) {
  const parts = [{ text: prompt }];
  if (image) parts.push({ inline_data: { mime_type: 'image/jpeg', data: image.split(',')[1] } });
  const body = { contents: [{ parts }], generationConfig: { temperature: 0.2 } };
  if (GROUNDING) body.tools = [{ google_search: {} }]; else body.generationConfig.responseMimeType = 'application/json';
  const j = await httpJson(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent`,
    { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': GEMINI_KEY }, body: JSON.stringify(body) });
  const text = ((j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || []).map(p => p.text || '').join('');
  if (!text) throw httpError(502, 'Gemini returned no answer' + (j.promptFeedback && j.promptFeedback.blockReason ? ' (' + j.promptFeedback.blockReason + ')' : '') + '.');
  return text;
}
async function askOpenAI(prompt, image) {
  const content = [{ type: 'text', text: prompt }];
  if (image) content.push({ type: 'image_url', image_url: { url: image } });
  const j = await httpJson('https://api.openai.com/v1/chat/completions', {
    method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + OPENAI_KEY },
    body: JSON.stringify({ model: OPENAI_MODEL, messages: [{ role: 'user', content }], response_format: { type: 'json_object' } })
  });
  const text = j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content;
  if (!text) throw httpError(502, 'OpenAI returned no answer.');
  return text;
}
function mockAnswer(note) {
  const label = (note || 'Photographed meal').slice(0, 40);
  return JSON.stringify({ items: [
    { name: label, portion: '1 serving', calories: 320, protein_g: 24, carbs_g: 30, fat_g: 12, fiber_g: 4, confidence: 'medium' },
    { name: 'Side salad', portion: '1 bowl', calories: 90, protein_g: 2, carbs_g: 8, fat_g: 6, fiber_g: 3, confidence: 'low' }
  ], notes: 'Mock AI response for testing.' });
}
function parseModelJson(t) {
  const a = t.indexOf('{'), b = t.lastIndexOf('}');
  if (a < 0 || b < a) throw httpError(502, 'The AI reply was not in the expected format. Try again.');
  try { return JSON.parse(t.slice(a, b + 1)); } catch (e) { throw httpError(502, 'The AI reply was not valid JSON. Try again.'); }
}
const num = v => { const x = parseFloat(v); return isFinite(x) ? Math.max(0, x) : 0; };
const r1 = v => Math.round(v * 10) / 10;

async function analyze(body) {
  const note = String(body.note || '').slice(0, 600).trim();
  const rest = String(body.restaurant || '').slice(0, 120).trim();
  const city = String(body.city || '').slice(0, 120).trim();
  const image = body.image ? String(body.image) : '';
  if (!note && !image) throw httpError(400, 'Add a photo or a short description first.');
  if (image && (!image.startsWith('data:image/jpeg;base64,') || image.length > 6e6)) throw httpError(400, 'Photo must be a JPEG under about 4 MB.');

  let text;
  if (MOCK_AI) text = mockAnswer(note);
  else {
    const want = body.provider === 'openai' || body.provider === 'gemini' ? body.provider : DEFAULT_PROVIDER;
    const provider = want === 'gemini' && GEMINI_KEY ? 'gemini' : want === 'openai' && OPENAI_KEY ? 'openai' : GEMINI_KEY ? 'gemini' : OPENAI_KEY ? 'openai' : null;
    if (!provider) throw httpError(503, 'No AI key is set on the server. Add GEMINI_API_KEY or OPENAI_API_KEY.');
    const prompt = buildPrompt(note, rest, city, body.savedFoods);
    text = await (provider === 'gemini' ? askGemini : askOpenAI)(prompt, image);
  }
  const obj = parseModelJson(text);
  const items = (Array.isArray(obj.items) ? obj.items : []).slice(0, 25).map(it => ({
    name: String(it.name || 'Food').slice(0, 120), portion: String(it.portion || '').slice(0, 80),
    kcal: Math.round(num(it.calories)), p: r1(num(it.protein_g)), c: r1(num(it.carbs_g)), f: r1(num(it.fat_g)), fiber: r1(num(it.fiber_g)),
    conf: String(it.confidence || '').slice(0, 10)
  }));
  if (!items.length) throw httpError(422, 'No food was found. Add more detail in the notes and try again.');
  return { items, notes: String(obj.notes || '').slice(0, 600) };
}

/* ---------- http plumbing ---------- */
function httpError(status, message) { const e = new Error(message); e.status = status; return e; }
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > limit) { reject(httpError(413, 'Request too large.')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch (e) { reject(httpError(400, 'Invalid JSON.')); }
    });
    req.on('error', reject);
  });
}
function send(res, status, obj, headers) {
  const body = JSON.stringify(obj);
  res.writeHead(status, Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, headers || {}));
  res.end(body);
}
function secureFlag(req) { return (TRUST_PROXY && req.headers['x-forwarded-proto'] === 'https') || req.socket.encrypted ? '; Secure' : ''; }
const SEC_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'X-Frame-Options': 'DENY',
  'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'"
};
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.webmanifest': 'application/manifest+json' };

function serveStatic(req, res, pathname) {
  const rel = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
  const file = path.join(__dirname, 'public', path.normalize(rel));
  if (!file.startsWith(path.join(__dirname, 'public') + path.sep)) { res.writeHead(404); return res.end('Not found'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, SEC_HEADERS); return res.end('Not found'); }
    res.writeHead(200, Object.assign({ 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' }, SEC_HEADERS));
    res.end(data);
  });
}

async function handleApi(req, res, pathname) {
  const ip = clientIp(req);
  if (pathname === '/api/health' && req.method === 'GET') {
    return send(res, 200, { ok: true, authRequired: !(ALLOW_NO_AUTH && !PASSCODE), authed: isAuthed(req),
      ai: { gemini: !!GEMINI_KEY || MOCK_AI, openai: !!OPENAI_KEY || MOCK_AI }, defaultProvider: DEFAULT_PROVIDER, mock: MOCK_AI });
  }
  if (pathname === '/api/login' && req.method === 'POST') {
    if (failedLoginCount('fail:' + ip, 15 * 60e3) >= 10) throw httpError(429, 'Too many attempts. Try again in 15 minutes.');
    const body = await readBody(req, 2e3);
    if (!PASSCODE || !safeEqual(body.passcode || '', PASSCODE)) {
      limited('fail:' + ip, 1e9, 15 * 60e3); // record a failure
      throw httpError(401, 'Wrong passcode.');
    }
    const cookie = `ml_session=${encodeURIComponent(makeToken())}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_DAYS * 86400}${secureFlag(req)}`;
    return send(res, 200, { ok: true }, { 'Set-Cookie': cookie });
  }
  if (pathname === '/api/logout' && req.method === 'POST') {
    return send(res, 200, { ok: true }, { 'Set-Cookie': `ml_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${secureFlag(req)}` });
  }

  if (!isAuthed(req)) throw httpError(401, 'Sign in required.');
  // block cross-site writes: browsers send Origin on POST/PUT, and it must match this host
  if (req.method !== 'GET') {
    const origin = req.headers.origin;
    if (origin && new URL(origin).host !== req.headers.host) throw httpError(403, 'Cross-site request blocked.');
  }

  if (pathname === '/api/state' && req.method === 'GET') return send(res, 200, getDoc());
  if (pathname === '/api/state' && req.method === 'PUT') {
    const body = await readBody(req, 30e6);
    if (!body.state || typeof body.state !== 'object' || !Array.isArray(body.state.entries)) throw httpError(400, 'Invalid state.');
    const cur = getDoc();
    if (!body.force && Number(body.baseRev) !== cur.rev) return send(res, 409, cur);
    const next = cur.rev + 1;
    putDoc(next, JSON.stringify(body.state));
    return send(res, 200, { rev: next });
  }
  if (pathname === '/api/analyze' && req.method === 'POST') {
    if (limited('ai:' + ip, 60, 3600e3)) throw httpError(429, 'Hourly analysis limit reached. Try again later.');
    const body = await readBody(req, 8e6);
    return send(res, 200, await analyze(body));
  }
  throw httpError(404, 'Not found.');
}

const server = http.createServer(async (req, res) => {
  try {
    const { pathname } = new URL(req.url, 'http://x');
    if (pathname.startsWith('/api/')) return await handleApi(req, res, pathname);
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    serveStatic(req, res, pathname);
  } catch (e) {
    const status = e.status || 500;
    if (status === 500) console.error(e);
    if (!res.headersSent) send(res, status, { error: status === 500 ? 'Server error.' : e.message });
  }
});
server.listen(PORT, HOST, () => {
  console.log(`Macro Log running on http://${HOST}:${PORT}  (AI: ${MOCK_AI ? 'MOCK' : [GEMINI_KEY && 'gemini', OPENAI_KEY && 'openai'].filter(Boolean).join('+') || 'none configured'})`);
});
