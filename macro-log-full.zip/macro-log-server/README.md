# Macro Log

Photo-based macro tracker. The browser app talks to a small Node server that
keeps your API keys, calls Gemini or OpenAI for you, and stores your log in SQLite so it syncs across devices.

No npm packages. Needs Node 22.5+.

## Run it on your computer

    cp .env.example .env      # then edit APP_PASSCODE and add a key
    set -a; . ./.env; set +a
    npm start

Open http://localhost:3000. To use it on your phone at home, open
`http://<your-computer's-LAN-IP>:3000` on the same Wi-Fi. For testing without spending
anything, run with `MOCK_AI=1` (returns fake meals).

## Put it online (so it works anywhere)

Any host that runs a Node or Docker app and has a persistent disk works. Set these
environment variables and mount a disk at `/data` (Docker) or set `DATA_DIR`:

- `APP_PASSCODE`  your sign-in passphrase
- `GEMINI_API_KEY` and/or `OPENAI_API_KEY`
- `TRUST_PROXY=1`  (already set in the Dockerfile)

Render, Fly.io and Railway all work. Use HTTPS (they provide it); the session cookie is marked Secure over HTTPS.

## What the server does

| Endpoint | Purpose |
| --- | --- |
| `POST /api/login` | Checks the passcode, sets a 30-day signed httpOnly cookie. 10 wrong tries per 15 minutes per IP. |
| `GET /api/state`, `PUT /api/state` | Loads and saves your whole log. Each save carries a revision number; if another device saved first, the app merges the two. |
| `POST /api/analyze` | Sends the photo and notes to Gemini or OpenAI with your saved foods, returns itemized macros. 60 per hour. |
| `GET /api/health` | Tells the app which AI providers are configured. |

Your data is one SQLite file, `data/macrolog.db`. The server also keeps one snapshot per day for 30 days
in the same file, so a bad sync can be undone. Back up the `data` folder.

This is a single-user design: one passcode, one log. For several people, run one copy per person.
